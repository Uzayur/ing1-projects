touch AUTHORS
echo "$1" >> ./AUTHORS
chmod 640 AUTHORS
