#First argument corespond to the text inside the AUTHORS file
#Second one is the permission of the AUTHORS file

 touch AUTHORS

 echo "$1" >> ./AUTHORS

chmod $2 AUTHORS
